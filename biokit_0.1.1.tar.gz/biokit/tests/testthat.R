library(testthat)
library(biokit)

test_check("biokit")
